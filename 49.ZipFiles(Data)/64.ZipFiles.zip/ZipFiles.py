# Author: Burak Dogancay
import os
from zipfile import ZipFile

def getSpecFile(pFileName):
    location = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__))) #it gets the folder location
    fileName= os.path.join(location,pFileName)#add file name to folder location
    return fileName

def zipFileContents():
    with ZipFile(getSpecFile('UavData.zip'),'r') as zip:
        zip.printdir()
        
def main():
    zipFileContents()
    

if __name__ == '__main__':
    main()